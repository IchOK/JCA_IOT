#ifndef _CPACMAN_H
#define _CPACMAN_H

#include "cRoot.h"

class cPacman : public cRoot{
  public:
    cPacman(int32_t solidRadius, int32_t glowRadius, sVector sAreaMin, sVector sAreaMax, sVector sPos, sVector sMove, int32_t grow, int32_t accelerate, sColor sRGB){
      _pos = sPos;
      _move = sMove;
      _areaMax = sAreaMax;
      _areaMin = sAreaMin;
      _grow = grow;
      _acc = accelerate;
      _rgb = sRGB;
      _solidRad = solidRadius;
      _glowRad = glowRadius;
    }
    void update(uint32_t iMillis){
      uint32_t fSec = iMillis;
      //Bewegung
      _pos.x += _move.x * fSec;
      _pos.y += _move.y * fSec;
      _pos.z += _move.z * fSec;
      //Kollision X
      if(_move.x > 0){
        if((_pos.x + _solidRad) >= _areaMax.x){
          _move.x *= -1;
        }
      }
      if(_move.x < 0){
        if((_pos.x - _solidRad) <= _areaMin.x){
          _move.x *= -1;
        }
      }
      //Kollision Y
      if(_move.y > 0){
        if((_pos.y + _solidRad) >= _areaMax.y){
          _move.y *= -1;
        }
      }
      if(_move.y < 0){
        if((_pos.y - _solidRad) <= _areaMin.y){
          _move.y *= -1;
        }
      }
      //Kollision Z
      if(_move.z > 0){
        if((_pos.z + _solidRad) >= _areaMax.z){
          _move.z *= -1;
        }
      }
      if(_move.z < 0){
        if((_pos.z - _solidRad) <= _areaMin.z){
          _move.z *= -1;
        }
      }
      //Beschleunigung
      _move.x += _acc * fSec;
      _move.y += _acc * fSec;
      _move.z += _acc * fSec;
      //Wachstum
      _solidRad += _grow * fSec;
      if(_solidRad < 0){
        _solidRad = 0;
      }
      _glowRad += _grow * fSec;
      if(_glowRad < 0){
        _glowRad = 0;
      }
    }
    void addColorRGB(sVector pos, uint32_t &r, uint32_t &g, uint32_t &b){
      uint32_t delta = getDistance(pos);
      if(delta <= _solidRad){
        r = r + ((uint32_t)_rgb.r);
        g = g + ((uint32_t)_rgb.g);
        b = b + ((uint32_t)_rgb.b);
      }else if(delta - _solidRad < _glowRad){
        uint32_t factor = _glowRad - (delta - _solidRad);
        r = r + ((uint32_t)_rgb.r) * factor / _glowRad;
        g = g + ((uint32_t)_rgb.g) * factor / _glowRad;
        b = b + ((uint32_t)_rgb.b) * factor / _glowRad;
      }
    }
  
  private:
    int32_t _solidRad;
    int32_t _glowRad;
};

#endif
