#ifndef _CROOT_H
#define _CROOT_H

typedef struct{
  int32_t x, y, z;
}sVector;

typedef struct{
  uint8_t r, g, b;
}sColor;

class cRoot{
  // x y z Werte in um
  public:
    cRoot(){;}
    virtual void update(uint32_t iMillis){;}
    virtual uint32_t getColor(sVector pos){return 0;}
    uint32_t getDistance(sVector pos){
      return sqrt(pow(pos.x - _pos.x,2) + pow(pos.y - _pos.y,2) + pow(pos.z - _pos.z,2));
    }
  protected:
    sVector _pos;
    sVector _move;
    sVector _areaMax;
    sVector _areaMin;
    int32_t _grow;
    int32_t _acc;
    sColor _rgb;
    int32_t _cSpeed;
    uint8_t _mode;
};

#endif
